import React from "react";
import time from "../assets/time.png";
import profit from "../assets/profit.png";
import inc from "../assets/inc.png";
import data from "../assets/data.png";

const Features = () => {
  return (
    <section class="bg-white text-white flex justify-center items-center">
      <div class="max-w-screen-xl px-4 py-8 sm:py-12 sm:px-6 lg:py-16 lg:px-8">
        <div class="max-w-xl mx-auto text-center">
          <h2 class="text-3xl font-bold sm:text-4xl text-gray-900">
            Trillion$sale is the solution!
          </h2>
        </div>

        <div
          className="grid gap-3 row-gap-4 sm:grid-cols-2 lg:grid-cols-3 "
          style={{ marginTop: "3%" }}
        >
          <div className="flex flex-col justify-between p-5 border rounded shadow-sm">
            <div>
              <div
                className="
              flex items-center justify-center w-16 h-16 mb-4  
              rounded-full
             bg-indigo-50"
                style={{ padding: "10px" }}
              >
                <img
                  className=""
                  src={time}
                  alt="logo"
                  // style={{ width: "80%", height: "100%" }}
                />
              </div>
              <h6 className="mb-2 font-semibold leading-5 text-gray-900">
                Saving time
              </h6>
              <p className="mb-3 text-sm text-gray-900">
                Trillionsale automates all your admin tasks like filling up CRM
                in details, sending follow up emails and relevant content to
                your clients
              </p>
            </div>
          </div>
          <div className="flex flex-col justify-between p-5 border rounded shadow-sm">
            <div>
              <div
                className="
              flex items-center justify-center w-16 h-16 mb-4  
              rounded-full
             bg-indigo-50"
                style={{ padding: "10px" }}
              >
                <img
                  className=""
                  src={profit}
                  alt="logo"
                  // style={{ width: "80%", height: "100%" }}
                />
              </div>
              <h6
                className="mb-2 font-semibold leading-5 text-gray-900
"
              >
                {" "}
                Maximise revenue
              </h6>
              <p className="mb-3 text-sm text-gray-900">
                Streamlined approach ensures your sales efforts are focused on
                the right leads, driving revenue growth
              </p>
            </div>
          </div>

          <div className="flex flex-col justify-between p-5 border rounded shadow-sm">
            <div>
              <div
                className="
              flex items-center justify-center w-16 h-16 mb-4  
              rounded-full
             bg-indigo-50"
                style={{ padding: "10px" }}
              >
                <img
                  className=""
                  src={data}
                  alt="logo"
                  // style={{ width: "80%", height: "100%" }}
                />
              </div>
              <h6 className="mb-2 font-semibold leading-5 Performance gaps text-gray-900">
                Data driven empowerment{" "}
              </h6>
              <p className="mb-3 text-sm text-gray-900">
                Empowers sales rep and the manager with clear data and CTA to
                bridge gaps and supercharge training efforts
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;
