import React, { useState, useEffect, useRef } from "react";
import { Dialog } from "@headlessui/react";
import { Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { WhatsappIcon, WhatsappShareButton } from "react-share";
import logo from "../assets/tlogo.png";
import Features from "./Features";

const navigation = [
  { name: "Product", href: "#" },
  { name: "Features", href: "#" },
  { name: "Marketplace", href: "#" },
  { name: "Company", href: "#" },
];

const Hero = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrollBackground, setScrollBackground] = useState(false);
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  const featuresRef = useRef();

  const scrollToFeatures = () => {
    featuresRef.current.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 0) {
        setScrollBackground(true);
      } else {
        setScrollBackground(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  useEffect(() => {
    const handleResize = () => {
      setWindowWidth(window.innerWidth);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <div className="">
      <header className="absolute inset-x-0 top-0 z-50">
        <nav
          aria-label="Global"
          style={{ width: "100%" }}
          className={
            scrollBackground
              ? "bg-white flex items-center justify-between p-6 lg:px-8 fixed"
              : "flex items-center justify-between p-6 lg:px-8 fixed"
          }
        >
          <div className="flex lg:flex-1 ">
            <a href="#" className="">
              <img
                className=""
                src={logo}
                alt="logo"
                style={{ width: windowWidth >= 1024 ? "20%" : "30%" }}
              />
            </a>
          </div>

          <div className="flex lg:hidden">
            <button
              type="button"
              className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
              onClick={() => setMobileMenuOpen(true)}
            >
              <span className="sr-only">Open main menu</span>
              <Bars3Icon className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>
          {windowWidth >= 1024 ? (
            <div
              className=" flex lg:gap-x-12 items-center justify-center lg:flex-1"
              style={{ marginRight: "3%" }}
            >
              {navigation.map((item) => (
                <button
                  key={item.name}
                  href={item.href}
                  className="text-sm font-semibold leading-6 text-gray-900"
                  onClick={scrollToFeatures}
                >
                  <section ref={featuresRef} id="features">
                    {item.name}
                  </section>
                </button>
              ))}
            </div>
          ) : null}

          <div className="hidden lg:flex lg:flex-1 lg:justify-end">
            <a
              href="https://calendly.com/abhishekchauhan1509/30min"
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-md bg-indigo-600 px-3.5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              Book Demo
              <span aria-hidden="true">&rarr;</span>
            </a>
          </div>
        </nav>
        <Dialog
          as="div"
          className="lg:hidden"
          open={mobileMenuOpen}
          onClose={setMobileMenuOpen}
        >
          <div className="fixed inset-0 z-50" />
          <Dialog.Panel className="fixed inset-y-0 right-0 z-50 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
            <div className="flex items-center justify-between">
              <a href="#" className="-m-1.5 p-1.5">
                <span className="sr-only">Trillion$sale</span>
                <img className="h-8 w-auto" src={logo} alt="" />
              </a>
              <button
                type="button"
                className="-m-2.5 rounded-md p-2.5 text-gray-700"
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="sr-only">Close menu</span>
                <XMarkIcon className="h-6 w-6" aria-hidden="true" />
              </button>
            </div>
            <div className="mt-6 flow-root">
              <div className="-my-6 divide-y divide-gray-500/10">
                <div className="space-y-2 py-6">
                  {navigation.map((item) => (
                    <a
                      key={item.name}
                      href={item.href}
                      className="-mx-3 block rounded-lg px-3 py-2 text-lg font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                    >
                      {item.name}
                    </a>
                  ))}
                </div>
                <div className="py-6">
                  <a
                    href="https://calendly.com/abhishekchauhan1509/30min"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="-mx-3 block rounded-lg px-3 py-2.5 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                  >
                    Book Demo
                  </a>
                </div>
              </div>
            </div>
          </Dialog.Panel>
        </Dialog>
      </header>

      <div className="relative isolate px-6 pt-14 lg:px-8">
        <div
          className="absolute inset-x-0 -top-40 -z-10 transform-gpu overflow-hidden blur-3xl sm:-top-80"
          aria-hidden="true"
        >
          <div
            className="relative left-[calc(50%-11rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 rotate-[30deg] bg-gradient-to-tr from-[#ff80b5] to-[#9089fc
] opacity-30 sm:left-[calc(50%-30rem)] sm:w-[72.1875rem]"
            style={{
              clipPath:
                "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
            }}
          />
        </div>
        <div className="flexsm:flex-row gap-8" style={{ marginTop: "8%" }}>
          <div className="hidden sm:mb-8 sm:flex sm:justify-center"></div>
          <div className="flex  items-center justify-center space-y-8">
            <div className="text-center">
              <h1
                className="text-4xl font-bold tracking-tight text-green-500 sm:text-6xl"
                style={{ fontSize: "64px" }}
              >
                Trillion$sale
              </h1>

              <div style={{ marginTop: "10px" }}>
                <h6 className="tracking-tight text-gray-900 sm:text-4xl">
                  Overachieve your sales target
                </h6>
              </div>

              <p
                className="mt-6 text-lg leading-8 text-gray-600"
                style={{ fontSize: "20px" }}
              >
                We provide personalised AI sales assistant so that you can save{" "}
                <br />
                time and solely focus on nurturing client connections and
                accelerating success
              </p>
              <div className="mt-10 flex items-center justify-center gap-x-6">
                <a
                  href="https://calendly.com/abhishekchauhan1509/30min"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="rounded-md bg-indigo-600 px-12 py-3 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
                  style={{ fontSize: "16px" }}
                >
                  Book Demo
                </a>
              </div>
            </div>
          </div>
        </div>

        <a
          href="https://api.whatsapp.com/send?phone=8447171485"
          target="_blank"
          rel="noopener noreferrer"
          style={{
            display: "flex",
            justifyContent: "flex-end",
            marginTop: windowWidth >= 1024 ? "12%" : "58%",
            zIndex: 1,
            position: "fixed",
            right: 0,
            marginRight: "28px",
          }}
        >
          <WhatsappIcon size={52} round={true} />
        </a>
        <div
          className="embed-responsive embed-responsive-16by9 relative w-full overflow-hidden"
          style={{
            paddingTop: "45%",
            marginTop: "8%",
            width: "80%",
            marginLeft: "10%",
          }}
        >
          <iframe
            className="embed-responsive-item absolute bottom-0 left-0 right-0 top-0 h-full w-full rounded-lg"
            src="https://player.vimeo.com/video/137857207"
            allowFullScreen
          />
        </div>
        <div
          className="absolute inset-x-0 top-[calc(100%-13rem)] -z-10 transform-gpu overflow-hidden blur-3xl sm:top-[calc(100%-30rem)]"
          aria-hidden="true"
        >
          <div
            // className="relative left-[calc(50%+3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-[#ff80b5] to-[#9089fc] opacity-30 sm:left-[calc(50%+36rem)] sm:w-[72.1875rem]"
            className="px-4 py-2 text-white rounded-md bg-gradient-to-r from-[#FAA746] to-[#5580FF]"
            // className="p-4 border-4 border-[#FF0270] bg-[#51C185] text-white"

            // className="h-[300px] bg-gradient-to-b from-[#FF0270] to-[#51C185]"
            // className="relative left-[calc(50% + 3rem)] aspect-[1155/678] w-[36.125rem] -translate-x-1/2 bg-gradient-to-tr from-[#FF0270] to-[#5580FF] opacity-30 sm:left-[calc(50% + 36rem)] sm:w-[72.1875rem]"
            style={{
              clipPath:
                "polygon(74.1% 44.1%, 100% 61.6%, 97.5% 26.9%, 85.5% 0.1%, 80.7% 2%, 72.5% 32.5%, 60.2% 62.4%, 52.4% 68.1%, 47.5% 58.3%, 45.2% 34.5%, 27.5% 76.7%, 0.1% 64.9%, 17.9% 100%, 27.6% 76.8%, 76.1% 97.7%, 74.1% 44.1%)",
            }}
          />
        </div>
      </div>
    </div>
  );
};

export default Hero;
