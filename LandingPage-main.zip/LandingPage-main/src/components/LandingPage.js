import React, { useRef } from "react";
import Hero from "./Hero";
import LogoClouds from "./LogoClouds";
import Problems from "./Problems";
import Features from "./Features";
import Testimonials from "./Testimonials";
import Footer from "./Footer";

const LandingPage = () => {
  return (
    <div>
      <Hero />
      <LogoClouds />
      <Problems />
      <Features />
      <Testimonials />
      <Footer />
    </div>
  );
};

export default LandingPage;
